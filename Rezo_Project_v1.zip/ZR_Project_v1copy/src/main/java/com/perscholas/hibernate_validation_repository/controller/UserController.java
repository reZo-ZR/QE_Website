package com.perscholas.hibernate_validation_repository.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.perscholas.hibernate_validation_repository.models.Region;
import com.perscholas.hibernate_validation_repository.models.User;
import com.perscholas.hibernate_validation_repository.repository.ChefRepository;
import com.perscholas.hibernate_validation_repository.repository.RegionRepository;
import com.perscholas.hibernate_validation_repository.repository.UserRepository;

@Controller
public class UserController {
	
	@Autowired
	UserRepository userRepository;
	ChefRepository chefRepository;
	
	@GetMapping("/")
	public String showSignIn(Model model) throws SQLException {
		//request	
	model.addAttribute("user", new User());
		return "SignIn";
	}

	@GetMapping("/showRegisterPage")
	public String showRegisterPage(Model model) {
		model.addAttribute("user2", new User());
		return "Register";
	}
	
	@PostMapping("/registerUser")
	public String addUser(@Valid @ModelAttribute("user2") User user, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		if (result.hasErrors()) {
			
			return "SignIn";
		}
		
		System.out.println(user.getUsername());
		System.out.println(user.getPassword());
		
		Integer addUserID = userRepository.addUser(user);

		if (addUserID == -1) {
			
			return "SignIn";
		}
		
		return "redirect:/";
	}
	
	@PostMapping("/verifyUser")
	public String verifyUser(@Valid @ModelAttribute("user") User user, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		if (result.hasErrors()) {
			
			return "SignIn";
		}
		User foundUser = userRepository.findUserByUsername(user);
		
		if(Objects.isNull(foundUser)) {
	
			return "SignIn";
		}
		else {
			
			if(foundUser.getPassword().equals(user.getPassword())) {
				return "SearchOptions";
			}
			else {
				return "SignIn";
			}
		
		}
		
		
	}
	
//CRUD for Region
	@GetMapping("/UserController")
	public String showRegion(Model model) throws SQLException {
		List<Region> allRegions = RegionRepository.
		model.addAttribute("allRegions", allRegions);
		model.addAttribute("region", new Region());
		return "Regions";
	}
	
	@PostMapping("/addAdd")
	public String addAdd(@Valid @ModelAttribute("add") Add add, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		if (result.hasErrors()) {
			List<Add> allAdds = addRepository.showAdds();
			model.addAttribute("allAdds", allAdds);
			return "Adds";
		}
		
		add.setStatus(1);
		Integer addId = addRepository.addAdd(add);

		if (addId == -1) {
			List<Add> allAdds = addRepository.showAdds();
			model.addAttribute("allAdds", allAdds);
			model.addAttribute("errorMessage", "Add add failed.");
			return "Adds";
		}
		
		return "redirect:/addController";
	}
	
	@GetMapping("/removeAdd/{addId}")
	public String removeAdd(@PathVariable Integer addId) 
			throws IOException, SQLException {
		Boolean b = addRepository.removeAdd(addId);
		System.out.println(b);
		return "forward:/addController";
	}
	
	@GetMapping("/orderAdd/{addStatus}")
	public String orderAdd(@PathVariable Integer addStatus) 
			throws IOException, SQLException {
		Boolean b = addRepository.updateStatusOne(addStatus);
		System.out.println(b);
		return "forward:/addController";
	}
	
	@GetMapping("/cancelAdd/{addStatus}")
	public String cancelAdd(@PathVariable Integer addStatus) 
			throws IOException, SQLException {
		Boolean b = addRepository.updateStatusTwo(addStatus);
		System.out.println(b);
		return "forward:/addController";
	}
	
}
	
}