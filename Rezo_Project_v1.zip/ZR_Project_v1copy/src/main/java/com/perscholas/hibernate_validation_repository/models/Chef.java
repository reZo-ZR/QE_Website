package com.perscholas.hibernate_validation_repository.models;

public class Chef {

}
