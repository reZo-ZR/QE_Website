package com.perscholas.hibernate_validation_repository.repository;

import java.util.List;

import com.perscholas.hibernate_validation_repository.models.Region;

public interface RegionRepository {

	List<Region> showAllRegions();
	Integer addRegion(Integer addRegionID);
	Boolean removeRegion(Integer removeRegionID);

}

