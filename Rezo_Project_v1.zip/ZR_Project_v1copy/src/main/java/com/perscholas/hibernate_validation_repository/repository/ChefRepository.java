package com.perscholas.hibernate_validation_repository.repository;

public interface ChefRepository {

}
