package com.perscholas.hibernate_validation_repository.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.repository.ChefRepository;

@Repository
public class MariaDB_ChefRepository implements ChefRepository {
	
	@Autowired
	private NamedParameterJdbcTemplate mariaDbJdbcTemplate;

	private final class ChefMapper implements RowMapper<Chef> {

		@Override
		public Chef mapRow(ResultSet rs, int rowNum) throws SQLException {
			Chef c = new Chef();
			c.setChefID(rs.getInt(1));
			c.setName(rs.getString(2));
			c.setAboutMe(rs.getString(3));
			
			return c;
		}
	}
	
	@Override
	public List<Chef> showAllChefs() {
		String ChefQuery = "SELECT * FROM chef";
		List <Chef> result = mariaDbJdbcTemplate.query(ChefQuery, new ChefMapper());
		return result;
	}
	
	

}
