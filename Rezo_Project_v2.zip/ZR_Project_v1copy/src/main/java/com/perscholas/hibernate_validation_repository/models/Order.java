package com.perscholas.hibernate_validation_repository.models;

import java.util.Date;

public class Order {
	
	private Integer orderID;
	private Date date;
	
	
	public Order() {
	}

	public Order(Integer orderID, Date date) {
		super();
		this.orderID = orderID;
		this.date = date;
	}

	public Integer getOrderID() {
		return orderID;
	}

	public void setOrderID(Integer orderID) {
		this.orderID = orderID;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
}
