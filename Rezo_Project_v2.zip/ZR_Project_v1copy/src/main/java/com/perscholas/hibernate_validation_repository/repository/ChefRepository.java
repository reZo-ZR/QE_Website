package com.perscholas.hibernate_validation_repository.repository;

import java.util.List;

import com.perscholas.hibernate_validation_repository.models.Chef;

public interface ChefRepository {

	List<Chef> showAllChefs();
}
