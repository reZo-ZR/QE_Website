package com.perscholas.hibernate_validation_repository.models;

public class Chef {
	
	private Integer chefID;
	private String name;
	private String aboutMe;
	
	public Chef() {
	}
		
	public Chef(Integer chefID, String name, String aboutMe) {
		super();
		this.chefID = chefID;
		this.name = name;
		this.aboutMe = aboutMe;
	}
	public Integer getChefID() {
		return chefID;
	}
	public void setChefID(Integer chefID) {
		this.chefID = chefID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAboutMe() {
		return aboutMe;
	}
	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}
	
}
