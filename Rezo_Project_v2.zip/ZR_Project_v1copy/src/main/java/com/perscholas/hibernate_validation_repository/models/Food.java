package com.perscholas.hibernate_validation_repository.models;

public class Food {
	
	private Integer foodID;
	private String name;
	private String description;
	private Double price;
	
	public Food() {
	}

	public Food(Integer foodID, String name, String description, Double price) {
		super();
		this.foodID = foodID;
		this.name = name;
		this.description = description;
		this.price = price;
	}

	public Integer getFoodID() {
		return foodID;
	}

	public void setFoodID(Integer foodID) {
		this.foodID = foodID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
}
