package com.perscholas.hibernate_validation_repository.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.perscholas.hibernate_validation_repository.models.Food;
import com.perscholas.hibernate_validation_repository.repository.FoodRepository;

@Repository
public class MariaDB_FoodRepository implements FoodRepository {

	@Autowired
	private NamedParameterJdbcTemplate mariaDbJdbcTemplate;

	private final class FoodMapper implements RowMapper<Food> {
		@Override
		public Food mapRow(ResultSet rs, int rowNum) throws SQLException {
			Food food = new Food();
			food.setFoodID(rs.getInt(1));
			food.setName(rs.getString(2));
			food.setDescription(rs.getString(3));
			food.setPrice(rs.getDouble(4));
			return food;
		}
	}

	@Override
	public List<Food> showAllFoods() {
		String FoodQuery = "SELECT * FROM food";
		List<Food> result = mariaDbJdbcTemplate.query(FoodQuery, new FoodMapper());
		return result;
	}
}
