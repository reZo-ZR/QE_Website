package com.perscholas.hibernate_validation_repository.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.models.Food;
import com.perscholas.hibernate_validation_repository.models.Region;
import com.perscholas.hibernate_validation_repository.models.User;
import com.perscholas.hibernate_validation_repository.repository.ChefRepository;
import com.perscholas.hibernate_validation_repository.repository.FoodRepository;
import com.perscholas.hibernate_validation_repository.repository.RegionRepository;
import com.perscholas.hibernate_validation_repository.repository.UserRepository;

@Controller
public class UserController {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ChefRepository chefRepository;
	
	@Autowired
	RegionRepository regionRepository;
	
	@Autowired
	FoodRepository foodRepository;
	
	@RequestMapping("/")
	public String showSignIn(Model model) throws SQLException {	
		model.addAttribute("user", new User());
		return "SignIn";
	}

	@GetMapping("/showRegisterPage")
	public String showRegisterPage(Model model) {
		model.addAttribute("user2", new User());
		return "Register";
	}
	
	@PostMapping("/registerUser")
	public String addUser(@Valid @ModelAttribute("user2") User user, 
						BindingResult result, Model model) 
						throws ClassNotFoundException, SQLException, IOException {
		if (result.hasErrors()) {			
			return "Register";
		}	
		
		System.out.println(user.getUsername());
		System.out.println(user.getPassword());
		
		Integer addUserID = userRepository.addUser(user);

		if (addUserID == -1) {			
			return "SignIn";
		}		
		return "redirect:/";
	}
	
	@PostMapping("/verifyUser")
	public String verifyUser(@Valid @ModelAttribute("user") User user, 
							BindingResult result, HttpSession session) 
							throws ClassNotFoundException, SQLException, IOException {
		System.out.println("verifyUser");
//		if (result.hasErrors()) {
//			System.out.println("Result errors.");
//			return "SignIn";
//		}
		
		User foundUser = userRepository.findUserByUsername(user);
		System.out.println("Found User: " + foundUser);
		if(Objects.isNull(foundUser)) {	
			return "SignIn";
		}
		else {			
			if(foundUser.getPassword().equals(user.getPassword())) {
				System.out.println("Passwords matched.");
				return "redirect:/returnToSearch";
			}
			else {
				return "SignIn";
			}
		}
	}
	
	@GetMapping("/showChefs")
	public String showAllChefs(@Valid @ModelAttribute("allChefs") Chef chef, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		           //Object
		List<Chef> allChefs = chefRepository.showAllChefs();
		model.addAttribute("allChefs", allChefs);
		for(Chef c: allChefs) {
			System.out.println(c.getName());
		}
		return "Chefs";
		}
		
	@GetMapping("/showRegions")
	public String showRegion(@Valid @ModelAttribute("region") Region region, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		List<Region> allRegions = regionRepository.showAllRegions();
		model.addAttribute("allRegions", allRegions);
		model.addAttribute("region", new Region());
		return "Region";
	}
	
	@GetMapping("/showFoodItems")
	public String showFoodItems(@Valid @ModelAttribute("food") Food food, 
			BindingResult result, Model model, @RequestParam String id, HttpSession sesh) 
					throws ClassNotFoundException, SQLException, IOException {
		
		List<Food> allFoods = foodRepository.showAllFoods();
		List<Food> foodList = new ArrayList<Food>();
		
		Integer cID = Integer.parseInt(id);
		sesh.setAttribute("id", cID);

		for(Food out:allFoods) {
			if(out.getF_chefID().equals(cID)) 
				foodList.add(out);
		}
		
		Chef chef = chefRepository.getChefByID(cID);
		model.addAttribute("sortName", chef);
		model.addAttribute("allFoods", foodList);
		return "Food";
	}

	
	@GetMapping("/showRegionFoodItems")
	public String showRegionFoodItems(@Valid @ModelAttribute("food") Food food, 
			BindingResult result, Model model, @RequestParam String id, HttpSession sesh) 
					throws ClassNotFoundException, SQLException, IOException {
			
			List<Food> allFoods = foodRepository.showAllFoods();
			List<Food> foodList = new ArrayList<Food>();
			
			Integer fID = Integer.parseInt(id);
			sesh.setAttribute("id", fID);
			
			for(Food out:allFoods) {
				if(out.getF_regionID().equals(fID)) 
					foodList.add(out);
			}
			Region region = regionRepository.getRegionByID(fID);
			model.addAttribute("sortName", region);
			model.addAttribute("allFoods", foodList);
			return "Food";	
	}
	
	
	@GetMapping("/addFoodToCart/{foodID}")
	public String addToCart(@PathVariable Integer foodID, HttpSession session) {
		
		Integer displayId = (Integer) session.getAttribute("id");
		
		/*
		 * Double price = (Double) session.getAttribute("price"); Double quantity =
		 * (Double) session.getAttribute("price"); Double foodPrice = price * quantity;
		 */
		
		Food food = foodRepository.getFoodByID(foodID);	
		List<Food> cart = (List<Food>) session.getAttribute("cart");
		cart.add(food);
		if(displayId%10 == 0) {
			return "redirect:/showRegionFoodItems/?id=" + displayId;
		}
		else if(displayId%11 == 0) {
			return "redirect:/showFoodItems/?id=" + displayId;
		}
		return "SearchOptions";
	
	}
	
	@GetMapping("/returnToSearch")
	public String backToHomepage() {
		return "SearchOptions";
	}
}





