package com.perscholas.hibernate_validation_repository.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.models.Food;
import com.perscholas.hibernate_validation_repository.models.Region;
import com.perscholas.hibernate_validation_repository.models.User;
import com.perscholas.hibernate_validation_repository.repository.ChefRepository;
import com.perscholas.hibernate_validation_repository.repository.FoodRepository;
import com.perscholas.hibernate_validation_repository.repository.RegionRepository;
import com.perscholas.hibernate_validation_repository.repository.UserRepository;

@Controller
public class AdminController {
		
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	FoodRepository foodRepository;
	
	@Autowired
	ChefRepository chefRepository;
	
	@Autowired
	RegionRepository regionRepository;
	
	
	@GetMapping("/showAdminSignIn")
	public String showSignIn(Model model) throws SQLException {	
		model.addAttribute("user", new User());
		return "AdminSignIn";
	}
	
	@PostMapping("/verifyAdmin")
	public String verifyAdmin(@Valid @ModelAttribute("user") User user, 
			BindingResult result, HttpSession session) 
					throws ClassNotFoundException, SQLException, IOException {
		if (result.hasErrors()) {
			
			return "AdminSignIn";
		}
		User foundUser = userRepository.findUserByUsername(user);
		
		Integer flag = 0;
		
		if (foundUser.getAdminFlag() == 0){
		}
		
		else if (foundUser.getAdminFlag() == 1){
			flag = 1;
		}			
		
		if(Objects.isNull(foundUser)) {
	
			return "AdminSignIn";
		}
		else {
			
			if(foundUser.getPassword().equals(user.getPassword())) {
				if(flag == 1) {
					return "AdminViews";
				}
				else {
					return "AdminSignIn";
				}				
			}
			else {
				return "SearchOptions";
			}
		}
	}
	
}

