package com.perscholas.cucumber.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/java/com/perscholas/cucumber/features/LoginLogoutOptionsRequirement.feature",
		glue="com/perscholas/cucumber/stepdef")

public class LoginLogoutOptionsRunner {

}
