package com.perscholas.hibernate_validation_repository.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.perscholas.hibernate_validation_repository.models.CartItem;
import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.models.Food;
import com.perscholas.hibernate_validation_repository.models.Region;
import com.perscholas.hibernate_validation_repository.models.User;
import com.perscholas.hibernate_validation_repository.repository.ChefRepository;
import com.perscholas.hibernate_validation_repository.repository.FoodRepository;
import com.perscholas.hibernate_validation_repository.repository.RegionRepository;
import com.perscholas.hibernate_validation_repository.repository.UserRepository;

@Controller
public class UserController {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ChefRepository chefRepository;
	
	@Autowired
	RegionRepository regionRepository;
	
	@Autowired
	FoodRepository foodRepository;
	
	@RequestMapping("/")
	public String showSignIn(Model model,HttpSession session) throws SQLException {	
		model.addAttribute("user", new User());
		return "SignIn";
	}

	@RequestMapping("/logout")
	public String showLogout(Model model,HttpSession session) throws SQLException {	
		
		System.out.println("Session User Name: " + session.getAttribute("username"));
		session.invalidate();
		model.addAttribute("user", new User());
		return "SignIn";
	}

	
	@GetMapping("/showRegisterPage")
	public String showRegisterPage(Model model) {
		model.addAttribute("user2", new User());
		return "Register";
	}
	
	@PostMapping("/registerUser")
	public String addUser(@Valid @ModelAttribute("user2") User user, 
						BindingResult result, Model model) 
						throws ClassNotFoundException, SQLException, IOException {
		if (result.hasErrors()) {			
			return "Register";
		}	
		
		System.out.println(user.getUsername());
		System.out.println(user.getPassword());
		
		Integer addUserID = userRepository.addUser(user);

		if (addUserID == -1) {			
			return "SignIn";
		}		
		return "redirect:/";
	}
	
	@PostMapping("/verifyUser")
	public String verifyUser(@Valid @ModelAttribute("user") User user, 
							BindingResult result, HttpSession session, Model model) 
							throws ClassNotFoundException, SQLException, IOException {
		System.out.println("verifyUser");
		User foundUser = userRepository.findUserByUsername(user);
		if(Objects.isNull(foundUser)) {	
			return "SignIn";
		}
		else {			
			if(foundUser.getPassword().equals(user.getPassword())) {
				session.setAttribute("username", user.getUsername());
				System.out.println("Passwords matched.");
				return "redirect:/returnToSearch";
			}
			else {
				
				List<CartItem> list=new ArrayList<>();
				session.setAttribute("cart", new ArrayList<Food>());
				model.addAttribute("cart", list);
				
				return "SignIn";
			}
		}
	}
	
	@GetMapping("/showChefs")
	public String showAllChefs(@Valid @ModelAttribute("allChefs") Chef chef, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		           //Object
		List<Chef> allChefs = chefRepository.showAllChefs();
		model.addAttribute("allChefs", allChefs);
		for(Chef c: allChefs) {
			System.out.println(c.getName());
		}
		return "Chefs";
		}
		
	@GetMapping("/showRegions")
	public String showRegion(@Valid @ModelAttribute("region") Region region, 
			BindingResult result, Model model) 
					throws ClassNotFoundException, SQLException, IOException {
		List<Region> allRegions = regionRepository.showAllRegions();
		model.addAttribute("allRegions", allRegions);
		model.addAttribute("region", new Region());
		return "Region";
	}
	
	@GetMapping("/showChefFoodItems")
	public String showChefFoodItems(@Valid @ModelAttribute("food") Food food, 
			BindingResult result, Model model, @RequestParam String id, HttpSession sesh) 
					throws ClassNotFoundException, SQLException, IOException {
		List<Food> allFoods = foodRepository.showAllFoods();
		List<Food> foodList = new ArrayList<Food>();
		Integer cID = Integer.parseInt(id);
		sesh.setAttribute("id", cID);
		for(Food out:allFoods) {
			if(out.getF_chefID().equals(cID)) 
				foodList.add(out);
		}
		
		Chef chef = chefRepository.getChefByID(cID);
		model.addAttribute("sortName", chef);
		model.addAttribute("allFoods", foodList);
		model.addAttribute("state","chef");
		model.addAttribute("cart", sesh.getAttribute("cart"));
		sesh.setAttribute("originPage", 1);
		return "Food";
	}

	
	@GetMapping("/showRegionFoodItems")
	public String showRegionFoodItems(@Valid @ModelAttribute("food") Food food, 
			BindingResult result, Model model, @RequestParam String id, HttpSession sesh) 
					throws ClassNotFoundException, SQLException, IOException {
			List<Food> allFoods = foodRepository.showAllFoods();
			List<Food> foodList = new ArrayList<Food>();
			Integer fID = Integer.parseInt(id);
			sesh.setAttribute("id", fID);
			for(Food out:allFoods) {
				if(out.getF_regionID().equals(fID)) 
					foodList.add(out);
			}
			Region region = regionRepository.getRegionByID(fID);
			model.addAttribute("sortName", region);
			model.addAttribute("allFoods", foodList);
			model.addAttribute("state","region");
			model.addAttribute("cart", sesh.getAttribute("cart"));
			sesh.setAttribute("originPage", 2);
			return "Food";	
	}
	
//	@GetMapping("/addFoodToCarts/{id}")
//	public String addToCart(@Valid @ModelAttribute("food") Food food, 
//			BindingResult result, Model model, @PathVariable String id, HttpSession sesh) 
//					throws ClassNotFoundException, SQLException, IOException {
//			
//			List<Food> allFoods = foodRepository.showAllFoods();
//			List<Food> foodList = new ArrayList<Food>();
//			
//			Integer fID = Integer.parseInt(id);
//			sesh.setAttribute("id", fID);
//			
//			for(Food out:allFoods) {
//				if(out.getF_regionID().equals(fID)) 
//					foodList.add(out);
//			}
//			Region region = regionRepository.getRegionByID(fID);
//			model.addAttribute("sortName", region);
//			model.addAttribute("allFoods", foodList);
//			
//			Chef chef = chefRepository.getChefByID(fID);
//			
//			
//			List<CartItem> list=new ArrayList<>();
//			
//		Food foodItem=	foodRepository.getFoodByID(Integer.valueOf(id));
//		CartItem item =new CartItem();
//		 item.setFood(food);
//		 item.setQuantity(1);
//		 list.add(item);
//		 
//			model.addAttribute("cart", list);
//			model.addAttribute("price", calculateprice(list));
//			return "Food";	
//	}
//	
//	
//	
//	
//	private Double calculateprice(List<CartItem> listOfCartItems) {
//		Double totalAmount=0d;
//		for(CartItem cartItems : listOfCartItems) {
//			totalAmount=totalAmount+cartItems.getQuantity()*cartItems.getFood().getPrice();
//		}
//		
//		return totalAmount;
//	}

	@GetMapping("/addFoodToCart/{foodID}")
	public String addToCart(@PathVariable Integer foodID,@ModelAttribute("cart") ArrayList<Food> cart, HttpSession session,Model model) {
		Integer displayId = (Integer) session.getAttribute("id");
		
	    cart=(ArrayList<Food>) session.getAttribute("cart");
			if(cart==null) {
			cart=new ArrayList<Food>();
			
		}
			if(cart.size()>0) {
			for(int i=0;i<cart.size();i++) {
				Food foods =  cart.get(i);
				if(foods.getFoodID()==foodID) {
					foods.setQuantity((foods.getQuantity()!=null?foods.getQuantity():0)+1);
					cart.set(i, foods);
					break;
				}else {
					Food food = foodRepository.getFoodByID(foodID);	
					food.setQuantity(1);
					cart.add(food);
					break;
				}
			}
			}
			else {
				Food food = foodRepository.getFoodByID(foodID);
				food.setQuantity(1);
				cart.add(food);			
			}
		
	
		model.addAttribute("cart", cart);
		session.setAttribute("cart", cart);
		List<Food> allFoods = foodRepository.showAllFoods();
		List<Food> foodList = new ArrayList<Food>();
		Integer fID =  (Integer) session.getAttribute("id");
		Integer origin = (Integer) session.getAttribute("originPage");
		if(origin == 1) {
			for(Food out:allFoods) {
				if(out.getF_chefID().equals(fID)) 
					foodList.add(out);
			}
			Chef chef = chefRepository.getChefByID(fID);
			model.addAttribute("sortName", chef);
			model.addAttribute("allFoods", foodList);
			return "Cart";
		}
		else if(origin ==2) {
			for(Food out:allFoods) {
				if(out.getF_regionID().equals(fID)) 
					foodList.add(out);
			}
			Region region = regionRepository.getRegionByID(fID);
			model.addAttribute("sortName", region);
			model.addAttribute("allFoods", foodList);
			return "Cart";
		}
		return "Food";
	}
	
	@GetMapping("/deleteCardwithFoodId/{foodID}")
	public String deleteCardwithFoodId(@PathVariable Integer foodID,@ModelAttribute("cart") ArrayList<Food> cart, HttpSession session,Model model) {
	    cart=(ArrayList<Food>) session.getAttribute("cart");
	    
		if(cart==null) {
			cart=new ArrayList<Food>();
		}
				for(int i=0;i<cart.size();i++) {
			Food foods =  cart.get(i);
			if(foods.getFoodID()==foodID) {
				cart.remove(i);
			}
		}
				model.addAttribute("cart", cart);
		session.setAttribute("cart", cart);
		return "Cart";

	}	
	
//	
//	@GetMapping Removetheitemsfrom shopping cart 
//	
//	JSP - retrive arraylist frp, a sesson list the price
//	
	@GetMapping("/returnToSearch")
	public String backToHomepage() {
		return "SearchOptions";
	}
	
	@GetMapping("/checkout")
	public String checkout(Model model) {
		model.addAttribute("uuid",UUID.randomUUID());
		return "Checkout";
	}
}





