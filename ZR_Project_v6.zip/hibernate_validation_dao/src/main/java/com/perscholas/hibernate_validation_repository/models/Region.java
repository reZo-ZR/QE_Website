package com.perscholas.hibernate_validation_repository.models;

public class Region {
	
	//Fields
	private Integer regionID;
	private String name;
	
	//Constructors
	public Region() {
	}
	
	public Region(Integer regionID, String name) {
		super();
		this.regionID = regionID;
		this.name = name;
	}
	
	//Getters and Setters
	public Integer getRegionID() {
		return regionID;
	}
	public void setRegionID(Integer regionID) {
		this.regionID = regionID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
