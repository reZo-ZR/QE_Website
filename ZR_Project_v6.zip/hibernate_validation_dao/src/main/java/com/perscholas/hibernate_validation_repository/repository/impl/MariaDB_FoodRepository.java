package com.perscholas.hibernate_validation_repository.repository.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.perscholas.hibernate_validation_repository.models.Chef;
import com.perscholas.hibernate_validation_repository.models.Food;
import com.perscholas.hibernate_validation_repository.models.Region;
import com.perscholas.hibernate_validation_repository.repository.FoodRepository;

@Repository
public class MariaDB_FoodRepository implements FoodRepository {

	@Autowired
	private NamedParameterJdbcTemplate mariaDbJdbcTemplate;

	private final class FoodMapper implements RowMapper<Food> {
		@Override
		public Food mapRow(ResultSet rs, int rowNum) throws SQLException {
			Food food = new Food();
			food.setFoodID(rs.getInt(1));
			food.setName(rs.getString(2));
			food.setDescription(rs.getString(3));
			food.setPrice(rs.getDouble(4));
			food.setF_regionID(rs.getInt(5));
			food.setF_chefID(rs.getInt(6));
			return food;
		}
	}

	@Override
	public List<Food> showAllFoods() {
		String FoodQuery = "SELECT * FROM food";
		List<Food> result = mariaDbJdbcTemplate.query(FoodQuery, new FoodMapper());
		return result;
	}
	
	@Override
	public Food getFoodByID(Integer id) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("id", id);
		String selectFood = "SELECT * FROM food WHERE foodID= :id";
		List <Food> result = mariaDbJdbcTemplate.query(selectFood, params, new FoodMapper());
		return result.get(0);
	}
	
	@Override
	public Integer addFood(Food food) {
        Integer id = -1;
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		
		params.addValue("name", food.getName());
		params.addValue("description", food.getDescription());
		params.addValue("price", food.getPrice());
		params.addValue("f_regionID", food.getF_regionID());
		params.addValue("f_chefID", food.getF_chefID());
		String createAddSql = "insert into food (name, description, price, f_regionID, f_chefID) values"
				+ "(:name, :description, :price, :f_regionID, :f_chefID)";
		
		
		KeyHolder keyHolder = new GeneratedKeyHolder();
		Integer createResult = mariaDbJdbcTemplate.update(createAddSql, 
				params, keyHolder);
	
		if (createResult > 0) {
			/* The Database returns a BigInteger that needs to be cast to an 
			 * int or Integer. */
			id = keyHolder.getKey().intValue();
		}
		return id;
	}

	@Override
	public void deleteFood(Food food) {
    
        MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("foodID", food.getFoodID());
		String deleteSql = "DELETE FROM food WHERE foodID=:foodID";
		mariaDbJdbcTemplate.update(deleteSql, params);
	}

	@Override
	public Integer updateFood(Food food) {
        MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("foodID", food.getFoodID());
		params.addValue("description", food.getDescription());
	    params.addValue("price", food.getPrice());
		String updateSql = "UPDATE food SET description = :description, price =:price WHERE foodID=:foodID";
		int rows = mariaDbJdbcTemplate.update(updateSql, params);
		return rows;
	}
	
}
