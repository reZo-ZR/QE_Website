package com.perscholas.hibernate_validation_repository.models;

public class CartItem {
		
		private Food food;
		private Integer quantity;
		
		public Food getFood() {
			return food;
		}
		public void setFood(Food food) {
			this.food = food;
		}
		public Integer getQuantity() {
			return quantity;
		}
		public void setQuantity(Integer quantity) {
			this.quantity = quantity;
		}

	}


