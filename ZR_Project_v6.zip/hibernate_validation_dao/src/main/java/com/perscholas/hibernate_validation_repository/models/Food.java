package com.perscholas.hibernate_validation_repository.models;

public class Food {
	
	private Integer foodID;
	private String name;
	private String description;
	private Double price;
	private Integer f_regionID;
	private Integer f_chefID;
	private Integer quantity;
	
	public Food() {
	}

	public Food(Integer foodID, String name, String description, Double price, Integer f_regionID, Integer f_chefID, Integer quantity) {
		super();
		this.foodID = foodID;
		this.name = name;
		this.description = description;
		this.price = price;
		this.f_regionID = f_regionID;
		this.f_chefID = f_chefID;
		this.quantity = quantity;
	}

	public Integer getFoodID() {
		return foodID;
	}

	public void setFoodID(Integer foodID) {
		this.foodID = foodID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getF_regionID() {
		return f_regionID;
	}

	public void setF_regionID(Integer f_regionID) {
		this.f_regionID = f_regionID;
	}
	
	public Integer getF_chefID() {
		return f_chefID;
	}

	public void setF_chefID(Integer f_chefID) {
		this.f_chefID = f_chefID;
	}
	
	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
}
