package com.perscholas.hibernate_validation_repository.repository.impl;

public class MariaDB_OrderRepository {

}
