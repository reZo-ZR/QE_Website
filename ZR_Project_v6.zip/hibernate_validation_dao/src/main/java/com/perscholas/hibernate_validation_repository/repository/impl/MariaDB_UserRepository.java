package com.perscholas.hibernate_validation_repository.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.perscholas.hibernate_validation_repository.models.User;
import com.perscholas.hibernate_validation_repository.repository.UserRepository;


@Repository("MariaDB_UserRepository")
public class MariaDB_UserRepository implements UserRepository {

	@Autowired
	private NamedParameterJdbcTemplate mariaDbJdbcTemplate;
	
	@Override
	public Integer addUser(User user) {
		Integer id = -1;
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		
		params.addValue("username", user.getUsername());
		params.addValue("password", user.getPassword());
		params.addValue("firstname", user.getFirstname());
		params.addValue("lastname", user.getLastname());
		params.addValue("email", user.getEmail());
		String createAddSql = "insert into users (username, password, firstname, lastname, email) values"
				+ "(:username, :password, :firstname, :lastname, :email)";
		
		
		KeyHolder keyHolder = new GeneratedKeyHolder();
		Integer createResult = mariaDbJdbcTemplate.update(createAddSql, 
				params, keyHolder);
	
		if (createResult > 0) {
			/* The Database returns a BigInteger that needs to be cast to an 
			 * int or Integer. */
			id = keyHolder.getKey().intValue();
		}
		return id;
	}

	private final class UserMapper implements RowMapper<User> {

		@Override
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User add = new User();
			add.setUserID(rs.getInt(1));
			add.setUsername(rs.getString(2));
			add.setPassword(rs.getString(3));
			add.setFirstname(rs.getString(4));
			add.setLastname(rs.getString(5));
			add.setEmail(rs.getString(6));
			add.setAdminFlag(rs.getInt(7));
			
			
			return add;
		}
	}

	@Override
	public User findUserByUsername(User input) {
		
		String selectUser = "SELECT * FROM users where username = :username";
		Map<String, Object> params = new HashMap<String, Object>();
		
		System.out.println(input.getUsername());
		System.out.println(input.getPassword());
		
		params.put("username", input.getUsername());
		
		try {
			User result = (User)mariaDbJdbcTemplate.queryForObject(selectUser, params, new UserMapper());
			return result;
		}catch(Exception e) {
			
			System.out.println("Unable to find it");
			return null;
		}
			
	}
	
}
